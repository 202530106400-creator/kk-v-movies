# KK & V MOVIES

Projeto inicial com catálogo, cadastro/login, favoritos e rota administrativa para adicionar títulos e arquivos.

## Rodar localmente
1. Instale Node.js 20 ou superior.
2. Extraia o ZIP e abra um terminal nesta pasta.
3. Execute `npm install`.
4. Copie `.env.example` para `.env` e altere `SESSION_SECRET`.
5. Execute `npm start` e abra `http://localhost:3000`.

## Administração
Defina `ADMIN_EMAIL` no ambiente com o e-mail usado no cadastro para habilitar a conta administradora. A rota `POST /api/admin/titles` aceita multipart/form-data com `name`, `description`, `category`, `year`, `poster` e `video`.

## Publicação
Este projeto é uma base inicial, não está publicado nem pronto para produção. Use hospedagem Node.js com armazenamento persistente, HTTPS, segredo forte e backups. Não envie `.env`, senhas ou conteúdo audiovisual sem autorização ao GitHub.
