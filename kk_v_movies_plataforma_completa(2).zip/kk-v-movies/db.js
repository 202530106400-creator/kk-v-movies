const Database = require("better-sqlite3");
const db = new Database("kk-v-movies.db");
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, password_hash TEXT);
CREATE TABLE IF NOT EXISTS titles(id INTEGER PRIMARY KEY, name TEXT, description TEXT, category TEXT, year INTEGER, poster TEXT, video TEXT);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER, title_id INTEGER, PRIMARY KEY(user_id,title_id));`);
if (!db.prepare("SELECT COUNT(*) n FROM titles").get().n) {
 const add=db.prepare("INSERT INTO titles(name,description,category,year,poster,video) VALUES(?,?,?,?,?,?)");
 add.run("Noite de Estreia","Título de demonstração","Filme",2026,"","");
 add.run("Novos Caminhos","Série de demonstração","Série",2026,"","");
}
module.exports=db;